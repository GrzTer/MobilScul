package com.example.zadaniepraktyczne02_kawa

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.zadaniepraktyczne02_kawa.databinding.ActivityMainBinding
import com.example.zadaniepraktyczne02_kawa.databinding.ActivityZamowienieBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(LayoutInflater.from(this))
        val bindingZamowienie = ActivityZamowienieBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        var kawa = ""
        var dodatki = arrayListOf<String>()
        with(binding){
            americano.setOnClickListener{
                kawa = "americano"
                americano.alpha = 1f
                cappuccino.alpha = 0.5f
                espresso.alpha = 0.5f
            }

            cappuccino.setOnClickListener{
                kawa = "cappuccino"
                cappuccino.alpha = 1f
                americano.alpha = 0.5f
                espresso.alpha = 0.5f
            }

            espresso.setOnClickListener{
                kawa = "espresso"
                espresso
                    .alpha = 1f
                cappuccino.alpha = 0.5f
                americano.alpha = 0.5f
            }
            Zamawiam.setOnClickListener{
                if (kawa == ""){
                    Toast.makeText(this@MainActivity, "Proszę wybrać kawę", Toast.LENGTH_LONG).show()
                }
                else {
                    if (Kakao.isChecked) {
                        dodatki.add("kakao")
                    }
                    if (Cukier.isChecked) {
                        dodatki.add("cukier")
                    }
                    if (Cynamon.isChecked) {
                        dodatki.add("cynamon")
                    }
                    bindingZamowienie.TEST.text = kawa
                    var tekst = ""
                    for (dodatek in dodatki){
                        tekst = tekst +" + "+ dodatek
                    }
                    bindingZamowienie.TEST.text = kawa + tekst
                    setContentView(bindingZamowienie.root)
                }
            }
        }
        with(bindingZamowienie){
            Powrot.setOnClickListener{
                setContentView(binding.root)
            }
            ZatwierdzTekst.setOnClickListener{
                Toast.makeText(this@MainActivity, "Zamowienie w trakcie realizacji", Toast.LENGTH_SHORT).show()
            }
        }
    }
}